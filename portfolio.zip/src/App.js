import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Navbar from "./components/Navbar/Navbar";
import Header from "./components/Header/Header";
function App() {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-12 p-0">
          <Navbar />
          <Header />
        </div>
      </div>
    </div>
  );
}

export default App;
