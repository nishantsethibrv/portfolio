import React from 'react'
import "./Header.css";
import { ReactTyped } from "react-typed";


const Header = () => {
  return (
    <div className="header-wraper">
        <div className="main-info">
            <h1>test</h1>
            <ReactTyped className="typed-text"
            strings={["Web Design", "Web Development", "Facebook Ads", "Google Ads"]} 
            typeSpeed={40}
            backSpeed={60}
            loop/>
            <a href="" className='btn-main-offer'>contact me </a>
        </div>
    </div>
  )
}

export default Header